from django.contrib import admin
from .models import Files

admin.site.register(Files)
