from django.shortcuts import render
from .models import Files
from pdf2docx import Converter
import os,glob
import uuid
from os import listdir
from django.http import HttpResponse 
def home(request):
    if request.method == 'POST':
        uid = uuid.uuid4()
        pdf = Files.objects.create(pdf=request.FILES.get('document_url'))
        cv = Converter(open(f'./media/{pdf.pdf}'))
        cv.convert(f'./media/generate_word/docs{uid}.docx',start=0, end=None)
        cv.close()
        return render(request,'index.html',{'url':f'./media/generate_word/docs{uid}.docx'})

    return render(request,'index.html')

