from django.contrib import admin
from django.urls import path,include
from .views import *
urlpatterns = [
    path('',home, name=''),
    path('remove_all/',remove_all, name=''),
]
